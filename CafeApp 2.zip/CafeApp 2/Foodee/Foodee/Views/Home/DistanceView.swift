//
//  DistanceView.swift
//  Foodee
//
//  Created by RMS on 05/07/2022.
//

import SwiftUI
import CoreLocation

struct DistanceView: View {
    
    @ObservedObject var viewModel = HomeViewModel()
    
    //@ObservedObject var currentLocation = CurrentLocationViewModel()
    
    @StateObject var locationManager = LocationViewModel()
    @StateObject var my_id = checkid()
    
    var userLatitude: String {
            return "\(locationManager.lastLocation?.coordinate.latitude ?? 0)"
        }
        
        var userLongitude: String {
            return "\(locationManager.lastLocation?.coordinate.longitude ?? 0)"
        }
    
    @State var sear = ""
    @State var mibool = true
    
    @State var distance1 = CLLocationDistance()
    
    var body: some View {
        VStack{
        HStack{
            TextEditor(text: $sear).foregroundColor(Color.blue)
            Button(action: {checking(tCheck: sear)}){
                Image(systemName: "person")
                
            }
        }.onAppear(perform: {viewModel.search()})
        .background(Color.green)
                .padding(20)
                .frame(width: 200, height: 100)
            
            VStack{
                if(mibool == true){
                    Text("WPISZ POPRAWNE DANE!")
                }
                else{
                
                    ForEach(viewModel.businesses, id: \.id){ bussines in
                        if(sear == bussines.name){
                            
                            let cor2 = CLLocationCoordinate2D(latitude: bussines.coordinates?.latitude ?? 0.0, longitude: bussines.coordinates?.longitude ?? 0.0)
                            /*let cor2 = CLLocationCoordinate2D(latitude: 50.294492, longitude: 18.67138)*/
                            let cor1 = CLLocationCoordinate2D(latitude: Double(userLatitude) ?? 0.0, longitude: Double(userLongitude) ?? 0.0)
                            
                            let distance = getDistance(from: cor1, to: cor2)
                            let distance2 = distance/1000
                            Text(String(distance2))
                            
                        }
                        else{
                        }
                    }
                }
            }
        }
 
        
        
    }
    
    func getDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> CLLocationDistance {
           let from = CLLocation(latitude: from.latitude, longitude: from.longitude)
           let to = CLLocation(latitude: to.latitude, longitude: to.longitude)
        print(from)
        print("l")
        print(to)
           return from.distance(from: to)
    }
    
    func checking(tCheck: String){
        if(tCheck.isEmpty){
            mibool = true
        }
        else{
            mibool = false
            
        }
    }
}

struct DistanceView_Previews: PreviewProvider {
    static var previews: some View {
        DistanceView()
    }
}
