

import SwiftUI
import CoreLocation

@available(iOS 15.0, *)
struct HomeView: View {
    
    @ObservedObject var viewModel = HomeViewModel()
    
    //@ObservedObject var currentLocation = CurrentLocationViewModel()
    
    @StateObject var locationManager = LocationViewModel()
    @StateObject var my_id = checkid()
    
    var userLatitude: String {
            return "\(locationManager.lastLocation?.coordinate.latitude ?? 0)"
        }
        
        var userLongitude: String {
            return "\(locationManager.lastLocation?.coordinate.longitude ?? 0)"
        }
    
   
    @State var selection: String?
    @State private var searchText = ""
    @State var namesList: [String] = []
    
    var body: some View {
        
        
        
        NavigationView{
            Form{
            Button(action: {viewModel.search()}){
                Image(systemName: "location.fill")
                    .font(.title2)
       
            }
                
                List(selection: $selection){
                
                    ForEach(viewModel.businesses, id: \.id){ business in
                    NavigationLink(destination: OneCafe()){
                        Text(business.name ?? "allal").onTapGesture(perform: {
                            print("dzialam")
                            my_id.my_id_one = business.name ?? "lala"
                        })
                        
                }                }            }
                
            }
            .listStyle(.plain)
            .navigationTitle("Cafes near you: ")
            .toolbar{
                ToolbarItem(placement: .navigationBarTrailing){
                    NavigationLink(destination: SearchingView()){
                        Image(systemName: "heart")
                    }
                    
                }
                ToolbarItem(placement: .navigationBarTrailing){
                    NavigationLink(destination: DistanceView()){
                        Image(systemName: "person")
                    }
                    
                }
            }
            .onAppear(perform: viewModel.search)
        }
        .environmentObject(my_id)
        .task {
            let coordinates = CLLocation(latitude: Double(userLatitude) ?? 0.0, longitude: Double(userLongitude) ?? 0.0)
           print(coordinates)
            print("lalalalallalalalalaallalalalal")
            print(userLatitude)
            print(userLongitude)
            
    }
        
    }
    
    /*func result(){
        
        for bussines in viewModel.businesses{
            namesList.append(bussines.name ?? "la")
            print(bussines.name!)
        }
       print(namesList)
    }
    var searchResults: [String] {
        print(namesList)
        
            if searchText.isEmpty {
                
                return namesList
            } else {
                return namesList.filter { $0.contains(searchText) }
            }
        }*/
    
    
}

@available(iOS 15.0, *)
struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
