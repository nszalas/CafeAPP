//
//  SearchingView.swift
//  Foodee
//
//  Created by RMS on 04/07/2022.
//

import SwiftUI

struct SearchingView: View {
    @ObservedObject var viewModel = HomeViewModel()
    
    @State var sear = ""
    @State var mibool = true
    @State var existsNow = false
    var body: some View {
        VStack{
        HStack{
            TextEditor(text: $sear).foregroundColor(Color.blue)
            Button(action: {checking(tCheck: sear)}){
                Image(systemName: "person")
                
            }
        }.onAppear(perform: {viewModel.search()})
        .background(Color.green)
                .padding(20)
                .frame(width: 200, height: 100)
            
            VStack{
                if(mibool == true){
                    Text("WPISZ POPRAWNE DANE!")
                }
                else{
                
                    ForEach(viewModel.businesses, id: \.id){ bussines in
                        if(sear == bussines.location?.city){
                            Text(String(bussines.name ?? "la") ?? "la")
                            Text(String(Double(bussines.rating ?? 0.0) ?? 0))
                            Text(String(bussines.location?.country ?? "la") ?? "la")
                            Text(String(bussines.price ?? "o"))
                        }
                        else{
                        }
                    }
                }
            }
        }
        
    }
    
    func checking(tCheck: String){
        if(tCheck.isEmpty){
            mibool = true
        }
        else{
            mibool = false
            
        }
    }
}

struct SearchingView_Previews: PreviewProvider {
    static var previews: some View {
        SearchingView()
    }
}
