//
//  checkid.swift
//  Foodee
//
//  Created by RMS on 02/07/2022.
//

import Foundation

class checkid: ObservableObject{
    @Published var my_id_one = ""
}
