//
//  OneCafe.swift
//  Foodee
//
//  Created by RMS on 29/06/2022.
//

import SwiftUI

@available(iOS 15.0, *)
struct OneCafe: View {
    
    @ObservedObject var viewModel = HomeViewModel()
    @State var homeView = HomeView()
    @EnvironmentObject var my_id: checkid
    //@Binding var my_id: String?
   /* var homeView = HomeView()
    var st = String(homeView.selection ?? "ja")*/
    var body: some View {
        
            
        VStack{
           
            let store = my_id.my_id_one
        Text(store)
        
        
            ForEach(viewModel.businesses, id: \.id){ business in
                if(store == String(business.name ?? "lal"))
                {
                    Text(String(Double(business.rating ?? 0) ?? 0.0))
                    Text(String("Nr telefonu: \(business.phone ?? "lala")"))
                    if(business.isClosed == true)
                    {Text("Zamkniete")}
                    else{
                        Text("Otwarte")
                    }
                    Text(String(business.location?.address1 ?? "lala"))
                    Text(String("\(business.location?.zipCode ?? "lala") \(business.location?.city ?? "lala")"))
                        
                }
            
                }

        }.onAppear(perform: {viewModel.search()})
    }

struct OneCafe_Previews: PreviewProvider {
    static var previews: some View {
        if #available(iOS 15.0, *) {
            OneCafe()
        }
    }
}
}
