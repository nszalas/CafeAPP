

import SwiftUI

struct PermissionView: View {
    var body: some View {
        GeometryReader { proxy in
            VStack {
                ZStack {
                    Image("food1")
                }.frame(height: proxy.size.height / 3)
                
                Text("Cafe searcher").font(.title)
                Text("Take a break and get the best cofee around").font(.headline)
                
                Spacer()
                
                Button(action: {}){
                    Text("Get started")
                }.padding().frame(maxWidth: proxy.size.width)
        }
            
           
            
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        PermissionView()
    }
}
