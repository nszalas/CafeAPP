//
//  CurrentLocation.swift
//  Foodee
//
//  Created by RMS on 21/06/2022.
//

import UIKit
import CoreLocation

class CurrentLocation: UIViewController, CLLocationManagerDelegate{
    @IBOutlet weak var latitudeLabel: UILabel!

    @IBOutlet weak var longitudeLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    var lat_double: Double? = nil
    var lon_double: Double? = nil
    
    var locationManager: CLLocationManager!
    
    
    
    override func viewDidLoad(){
        super.viewDidLoad()
            locationManager = CLLocationManager()
            locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        
        }
        
        @IBAction func detectLocationBtnClicked(_ sender: UIButton){
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.requestWhenInUseAuthorization()
            
            
            
            if CLLocationManager.locationServicesEnabled(){
                print("Location Enabled")
            }
            else {
                print("Location Not Enabled")
            }
        }
    
    
        func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
            let userLocation = locations[0] as CLLocation
            
            guard let locationValue: CLLocationCoordinate2D = manager.location?.coordinate else{ return }
            let latitude = locationValue.latitude
            let longitude = locationValue.longitude
            print("BBBBBBBBBBBBBBBBBBBBBBBBBBBBBB")
            print(latitude)
            let geocoder = CLGeocoder()
            geocoder.reverseGeocodeLocation(userLocation){
                (placemarks, error) in
                if(error != nil) {
                    print("error")
                }
                let placemark = placemarks! as [CLPlacemark]
                if (placemark.count>0){
                    let placemark = placemarks![0]
                    
                    let locality = placemark.locality ?? ""
                    let administrativeArea = placemark.administrativeArea ?? ""
                    let country = placemark.country ?? ""
                    
                    print("Address: \(locality), \(administrativeArea), \(country)")
                }
                
            }
            lat_double = Double(latitude)
            lon_double = Double(longitude)
        }
    
    /*func setValLat(_ location: CLLocation) -> Double?{
        
        let latitude = CLLocationCoordinate2D(location.coordinate.latitude)
        NSLog(String(latitude)+"lalalallalalalalallalalalalalalalalalala")
        let longitude = userLocation.coordinate.longitude
        
        lat_double = Double(latitude)
        
        return lat_double
        
    }*/
    
    
    /*func setValueLatitude() -> Double? {
    
        if latitudeLabel != nil {
            guard let latitude = latitudeLabel.text else { return 46.52 }
        
        lat_double = Double(latitude)
        
            return lat_double}
        else { return 46.8 }
    }
    
    func setValueLongitude() -> Double? {
        
        if longitudeLabel != nil{
    
            guard let longitude = longitudeLabel.text else { return -71 }
        
        lon_double = Double(longitude)
        
            return lon_double}
        
        else { return -71.2 }
        
    }*/
    }

