//
//  CurrentLocationViewModel.swift
//  Foodee
//
//  Created by RMS on 21/06/2022.
//

import Foundation

import Combine


final class CurrentLocationViewModel: ObservableObject{
    
    @Published var currentLocation = [CurrentLocation]()
    //var butnclic = CurrentLocation.detectLocationBtnClicked(sender: Button)

}
