

import SwiftUI
import CoreLocation

@available(iOS 15.0, *)
struct HomeView: View {
    
    @ObservedObject var viewModel = HomeViewModel()
    
    //@ObservedObject var currentLocation = CurrentLocationViewModel()
    
    @StateObject var locationManager = LocationViewModel()
    @StateObject var my_id = checkid()
    
    var userLatitude: String {
            return "\(locationManager.lastLocation?.coordinate.latitude ?? 0)"
        }
        
        var userLongitude: String {
            return "\(locationManager.lastLocation?.coordinate.longitude ?? 0)"
        }
    
   
    @State var selection: String?
   
    
    var body: some View {
        
        
        
        NavigationView{
            Form{
            Button(action: {viewModel.search()}){
                Image(systemName: "location.fill")
                    .font(.title2)
       
            }
                List(selection: $selection){
                
                ForEach(viewModel.businesses, id: \.id){ business in
                    NavigationLink(destination: OneCafe()){
                        Text(business.name ?? "no name yeah").onTapGesture(perform: {
                            print("dzialam")
                            my_id.my_id_one = business.name ?? "llala"
                        })
                        
                }
                   // my_id = business.name
                }
            
            }
                
            }
            .listStyle(.plain)
            .navigationTitle("Cafes near you: ")
            .toolbar{
                ToolbarItem(placement: .navigationBarTrailing){
                    Image(systemName: "person")
        }
                
            }
            .onAppear(perform: viewModel.search)
        
        }
        .environmentObject(my_id)
        .task {
            let coordinates = CLLocation(latitude: Double(userLatitude) ?? 0.0, longitude: Double(userLongitude) ?? 0.0)
           print(coordinates)
            print("lalalalallalalalalaallalalalal")
            print(userLatitude)
            print(userLongitude)
    }
        
    }
}

@available(iOS 15.0, *)
struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
