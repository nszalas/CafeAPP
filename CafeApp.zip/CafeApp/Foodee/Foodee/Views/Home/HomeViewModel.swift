//
//  HomeViewModel.swift
//  Foodee
//
//  Created by RMS on 20/06/2022.
//

import Foundation
import Combine
import CoreLocation
import UIKit

class HomeViewModel: ObservableObject{
    
    @Published var businesses = [Business]()
    @Published var searchText = ""
    @Published var locationManager = LocationViewModel()

    
    func search(){
        
        let live = ApiService.live
        print("FFFFFFFFFFFFFFFFF")
        print(locationManager.lastLocation)

        
        live.search("coffee", .init(latitude: locationManager.lastLocation?.coordinate.latitude  ?? -15, longitude: locationManager.lastLocation?.coordinate.longitude ?? 52),nil)
            .assign(to: &$businesses)
        
        /*live.search("coffee", .init(latitude: 50.2944923 ?? -15, longitude: 18.6713802 ?? 52),nil)
         .assign(to: &$businesses)*/
    }
}


// New York latitude: 40.7142700, longitude: -74.0059700
// Gliwice latitude: 50.2944923, longitude: 18.6713802
