//
//  ViewModyfier.swift
//  Foodee
//
//  Created by RMS on 02/07/2022.
//

import Foundation
import SwiftUI



struct ViewDidLoadModifier: ViewModifier {
 @ObservedObject var viewModel = HomeViewModel()
    
    
    @State private var didLoad = false
    private let action: HomeViewModel?

    init(perform action: viewModel.search: () = nil) {
        self.action = action
    }

    func body(content: Content) -> some View {
        content.onAppear {
            if didLoad == false {
                didLoad = true
                action?()
            }
        }
    }

}
